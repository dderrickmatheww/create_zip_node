# npm package: create_zip

***To install***
- npm i -g create_zip

***How to use***
- Navigate to the directory you would like to create your project in.
- Open a terminal
- Run command: "create-proj"
- Follow and answer all questions prompted

***NPM Packages used***
- jszip (outside package)
    - Security overview: https://snyk.io/advisor/npm-package/jszip
- fs (apart of node)
- util (apart of node)
- child_process (apart of node)
